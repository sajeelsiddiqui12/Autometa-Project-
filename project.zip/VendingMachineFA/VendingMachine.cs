﻿using System.Collections.Generic;

namespace VendingMachineFA
{
    public class Transition
    {
        public int From { get; set; }
        public int To { get; set; }
        public string Label { get; set; }

        public Transition(int from, int to, string label)
        {
            From = from;
            To = to;
            Label = label;
        }
    }

    public class Product
    {
        public string Name { get; set; }
        public int Price { get; set; }

        public override string ToString()
        {
            return $"{Name} ({Price} Rs)";
        }
    }

    public class VendingMachine
    {
        public int CurrentAmount { get; set; }
        public List<Product> Products { get; } = new List<Product>();
        public List<Transition> Transitions { get; } = new List<Transition>();

        public void InsertCoin(int coin)
        {
            int from = CurrentAmount;
            CurrentAmount += coin;
            Transitions.Add(new Transition(from, CurrentAmount, $"{coin}"));
        }

        public bool PurchaseProduct(Product product)
        {
            if (product.Price > 100)
            {
                // Product too expensive to be dispensed
                return false;
            }

            if (CurrentAmount >= product.Price)
            {
                // Record transition from current state to "dispensed" state
                int from = CurrentAmount;
                Transitions.Add(new Transition(from, -1, $"Dispense {product.Name}"));
                CurrentAmount = 0;

                return true;
            }
            return false;
        }

        public void Reset()
        {
            CurrentAmount = 0;
            Transitions.Clear();
        }
    }
}
