﻿using System.Threading.Tasks;
using System;

namespace VendingMachineFA
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlFA = new System.Windows.Forms.Panel();
            this.btnCoin5 = new System.Windows.Forms.Button();
            this.btnCoin10 = new System.Windows.Forms.Button();
            this.btnCoin20 = new System.Windows.Forms.Button();
            this.btnPurchase = new System.Windows.Forms.Button();
            this.lstProducts = new System.Windows.Forms.ListBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCoin1 = new System.Windows.Forms.Button();
            this.btnCoin2 = new System.Windows.Forms.Button();
            this.btnCoin50 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pnlFA
            // 
            this.pnlFA.BackColor = System.Drawing.Color.White;
            this.pnlFA.Location = new System.Drawing.Point(0, 0);
            this.pnlFA.Name = "pnlFA";
            this.pnlFA.Size = new System.Drawing.Size(560, 422);
            this.pnlFA.TabIndex = 0;
            this.pnlFA.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlFA_Paint);
            // 
            // btnCoin5
            // 
            this.btnCoin5.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin5.Location = new System.Drawing.Point(12, 440);
            this.btnCoin5.Name = "btnCoin5";
            this.btnCoin5.Size = new System.Drawing.Size(109, 48);
            this.btnCoin5.TabIndex = 0;
            this.btnCoin5.Tag = "5";
            this.btnCoin5.Text = "Insert 5";
            this.btnCoin5.UseVisualStyleBackColor = false;
            this.btnCoin5.Click += new System.EventHandler(this.CoinButton_Click);
            // 
            // btnCoin10
            // 
            this.btnCoin10.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin10.Location = new System.Drawing.Point(127, 440);
            this.btnCoin10.Name = "btnCoin10";
            this.btnCoin10.Size = new System.Drawing.Size(101, 48);
            this.btnCoin10.TabIndex = 1;
            this.btnCoin10.Tag = "10";
            this.btnCoin10.Text = "Insert 10";
            this.btnCoin10.UseVisualStyleBackColor = false;
            this.btnCoin10.Click += new System.EventHandler(this.CoinButton_Click);
            // 
            // btnCoin20
            // 
            this.btnCoin20.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin20.Location = new System.Drawing.Point(242, 440);
            this.btnCoin20.Name = "btnCoin20";
            this.btnCoin20.Size = new System.Drawing.Size(114, 48);
            this.btnCoin20.TabIndex = 2;
            this.btnCoin20.Tag = "20";
            this.btnCoin20.Text = "Insert 20";
            this.btnCoin20.UseVisualStyleBackColor = false;
            this.btnCoin20.Click += new System.EventHandler(this.CoinButton_Click);
            // 
            // btnPurchase
            // 
            this.btnPurchase.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnPurchase.Location = new System.Drawing.Point(569, 200);
            this.btnPurchase.Name = "btnPurchase";
            this.btnPurchase.Size = new System.Drawing.Size(119, 69);
            this.btnPurchase.TabIndex = 3;
            this.btnPurchase.Text = "Purchase";
            this.btnPurchase.UseVisualStyleBackColor = false;
            this.btnPurchase.Click += new System.EventHandler(this.btnPurchase_Click);
           
            // 
            // lstProducts
            // 
            this.lstProducts.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lstProducts.FormattingEnabled = true;
            this.lstProducts.Location = new System.Drawing.Point(568, 12);
            this.lstProducts.Name = "lstProducts";
            this.lstProducts.Size = new System.Drawing.Size(120, 160);
            this.lstProducts.TabIndex = 4;
         
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.IndianRed;
            this.btnReset.Location = new System.Drawing.Point(587, 297);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(101, 36);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnCoin1
            // 
            this.btnCoin1.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin1.Location = new System.Drawing.Point(362, 440);
            this.btnCoin1.Name = "btnCoin1";
            this.btnCoin1.Size = new System.Drawing.Size(110, 48);
            this.btnCoin1.TabIndex = 6;
            this.btnCoin1.Tag = "1";
            this.btnCoin1.Text = "Insert 1";
            this.btnCoin1.UseVisualStyleBackColor = false;
            this.btnCoin1.Click += new System.EventHandler(this.CoinButton_Click);
            // 
            // btnCoin2
            // 
            this.btnCoin2.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin2.Location = new System.Drawing.Point(478, 440);
            this.btnCoin2.Name = "btnCoin2";
            this.btnCoin2.Size = new System.Drawing.Size(106, 48);
            this.btnCoin2.TabIndex = 7;
            this.btnCoin2.Tag = "2";
            this.btnCoin2.Text = "Insert 2";
            this.btnCoin2.UseVisualStyleBackColor = false;
            this.btnCoin2.Click += new System.EventHandler(this.CoinButton_Click);
            // 
            // btnCoin50
            // 
            this.btnCoin50.BackColor = System.Drawing.Color.DarkSalmon;
            this.btnCoin50.Location = new System.Drawing.Point(590, 440);
            this.btnCoin50.Name = "btnCoin50";
            this.btnCoin50.Size = new System.Drawing.Size(98, 48);
            this.btnCoin50.TabIndex = 8;
            this.btnCoin50.Tag = "50";
            this.btnCoin50.Text = "Insert 50";
            this.btnCoin50.UseVisualStyleBackColor = false;
            this.btnCoin50.Click += new System.EventHandler(this.CoinButton_Click);
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 500);
            this.Controls.Add(this.btnCoin50);
            this.Controls.Add(this.btnCoin2);
            this.Controls.Add(this.btnCoin1);
            this.Controls.Add(this.lstProducts);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnPurchase);
            this.Controls.Add(this.btnCoin20);
            this.Controls.Add(this.btnCoin10);
            this.Controls.Add(this.btnCoin5);
            this.Controls.Add(this.pnlFA);
            this.Name = "MainForm";
            this.Text = "Vending Machine FA";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlFA;
        private System.Windows.Forms.Button btnCoin20;
        private System.Windows.Forms.Button btnCoin10;
        private System.Windows.Forms.Button btnCoin5;
        private System.Windows.Forms.Button btnPurchase;
        private System.Windows.Forms.ListBox lstProducts;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCoin1;
        private System.Windows.Forms.Button btnCoin2;
        private System.Windows.Forms.Button btnCoin50;
       
    }
}