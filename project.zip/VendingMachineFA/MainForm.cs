﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace VendingMachineFA
{
    public partial class MainForm : Form
    {
        private readonly VendingMachine vm = new VendingMachine();
        private readonly List<int> states = new List<int>();
        private readonly Dictionary<int, Point> statePositions = new Dictionary<int, Point>();
        private readonly List<Transition> allTransitions = new List<Transition>();
        




        public MainForm()
        {
            InitializeComponent();
           // this.pnlFA.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlFA_Paint);
            InitializeProducts();
            lstProducts.DataSource = vm.Products; // Bind listbox
            lstProducts.DisplayMember = "Name";
            GenerateStates();
            GenerateTransitions();
            CalculatePositions();
            pnlFA.Invalidate();
        }
        

        private void InitializeProducts()
        {
            vm.Products.AddRange(new[]
            {
                new Product { Name = "Pepsi     Rs.30", Price = 30 },
                new Product { Name = "Coke      Rs.25", Price = 25 },
                new Product { Name = "Water     Rs.20", Price = 20 },
                new Product { Name = "Epic      Rs.80", Price = 80 },
                new Product { Name = "Red Bull  Rs.95", Price = 95 },
                new Product { Name = "Slice Juice   Rs.52", Price = 52 },
                new Product { Name = "7Up       Rs.28", Price = 28 },
                new Product { Name = "Fanta     Rs.26", Price = 26 },
                new Product { Name = "Sting     Rs.40", Price = 40 },
                new Product { Name = "Aquafina  Rs.22", Price = 22 },
                new Product { Name = "Mountain Dew Rs.33", Price = 33 },
                new Product { Name = "Appy Fizz Rs.45", Price = 45 },
                new Product { Name = "Mirinda   Rs.29", Price = 29 },
                new Product { Name = "Nescafe   Rs.65", Price = 65 },
                new Product { Name = "Lays      Rs.35", Price = 35 },
                new Product { Name = "Snickers  Rs.40", Price = 40 },
                new Product { Name = "KitKat    Rs.30", Price = 30 },
                new Product { Name = "Dairy Milk Rs.45", Price = 45 },
                new Product { Name = "Cold Coffee Rs.55", Price = 55 },
                new Product { Name = "Nestle Juice Rs.50", Price = 50 },
                new Product { Name = "Cappy      Rs.38", Price = 38 },
                new Product { Name = "Pakola     Rs.110", Price = 110}

            });

            lstProducts.DataSource = vm.Products;
        }

        private void GenerateStates()
        {
            for (int i = 0; i <= 100; i+=5)
                states.Add(i);
        }

        //private void GenerateTransitions()
        //{
        //    foreach (var from in states)
        //    {
        //        foreach (var coin in new[] { 5, 10, 20 })
        //        {
        //            int to = from + coin;
        //            if (to <= 60)
        //                allTransitions.Add(new Transition(from, to, coin.ToString()));
        //        }
        //    }
        //}
        private void GenerateTransitions()
        {
            foreach (var from in states)
            {
                foreach (var coin in new[] { 1, 2, 5, 10, 20, 50 }) //  added 1, 2, 50
                {
                    int to = from + coin;
                    if (to <= 100) // increase to match highest possible amount
                        allTransitions.Add(new Transition(from, to, coin.ToString()));
                }
            }
        }

        private void CalculatePositions()
        {
            foreach (var state in states)
            {
                int index = state / 5;
                int x = (index % 4) * 100 + 50;
                int y = (index / 4) * 70 + 50;
                statePositions[state] = new Point(x, y);
            }
        }

        private void pnlFA_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Color.White);

            // Draw all possible transitions (gray)
            foreach (var t in allTransitions)
            {
                if (statePositions.ContainsKey(t.From) && statePositions.ContainsKey(t.To))
                    DrawTransition(g, t.From, t.To, t.Label, Brushes.LightGray);
            }

            // Draw active coin transitions (red)
            foreach (var t in vm.Transitions.Where(t => t.To != -1))
            {
                if (statePositions.ContainsKey(t.From) && statePositions.ContainsKey(t.To))
                    DrawTransition(g, t.From, t.To, t.Label, Brushes.Red);
            }

            // Draw purchase transitions (green)
            foreach (var t in vm.Transitions.Where(t => t.To == -1))
            {
                if (statePositions.ContainsKey(t.From))
                {
                    var start = statePositions[t.From];
                    var end = new Point(start.X + 100, start.Y); // Position for "dispensed" state
                    DrawTransition(g, t.From, -1, t.Label, Brushes.Green);
                }
            }

            // Draw states
            foreach (var state in states)
            {
                DrawState(g, state, state == vm.CurrentAmount ? Brushes.Red : Brushes.White);
            }
        }

        //    // Draw highlighted transitions
        //    foreach (var t in vm.Transitions)
        //    {
        //        if (statePositions.ContainsKey(t.From) && statePositions.ContainsKey(t.To))
        //        {
        //            DrawTransition(g, t.From, t.To, t.Label, Brushes.Red);
        //        }
        //    }

        //    // Draw states
        //    foreach (var state in states)
        //    {
        //        DrawState(g, state, state == vm.CurrentAmount ? Brushes.Red : Brushes.White);
        //    }
        //}

        private void DrawTransition(Graphics g, int from, int to, string label, Brush brush)
        {
            if (from == to) return; // Skip self-transitions

            var start = statePositions[from];
            var end = statePositions[to];
            var pen = new Pen(brush, 2);

            // Adjust line to start/end at circle edges
            var angle = (float)Math.Atan2(end.Y - start.Y, end.X - start.X);
            var radius = 20; // Circle radius
            start = new Point(
                (int)(start.X + radius * Math.Cos(angle)),
                (int)(start.Y + radius * Math.Sin(angle))
            );
            end = new Point(
                (int)(end.X - radius * Math.Cos(angle)),
                (int)(end.Y - radius * Math.Sin(angle))
            );

            g.DrawLine(pen, start, end);
            DrawArrow(g, pen, start, end);
            DrawLabel(g, label, brush, start, end);
        }
        private void DrawArrow(Graphics g, Pen pen, Point start, Point end)
        {
            var arrowSize = 10;
            var angle = (float)Math.Atan2(end.Y - start.Y, end.X - start.X);
            var p1 = new PointF(
                end.X - arrowSize * (float)Math.Cos(angle) + arrowSize * (float)Math.Sin(angle),
                end.Y - arrowSize * (float)Math.Sin(angle) - arrowSize * (float)Math.Cos(angle));
            var p2 = new PointF(
                end.X - arrowSize * (float)Math.Cos(angle) - arrowSize * (float)Math.Sin(angle),
                end.Y - arrowSize * (float)Math.Sin(angle) + arrowSize * (float)Math.Cos(angle));

            g.FillPolygon(pen.Brush, new[] { end, p1, p2 });
        }

        private void DrawLabel(Graphics g, string label, Brush brush, Point start, Point end)
        {
            var labelPos = new Point((start.X + end.X) / 2, (start.Y + end.Y) / 2);
            g.DrawString(label, Font, brush, labelPos);
        }

        private void DrawState(Graphics g, int state, Brush fill)
        {
            var pos = statePositions[state];
            g.FillEllipse(fill, pos.X - 20, pos.Y - 20, 40, 40);
            g.DrawEllipse(Pens.Black, pos.X - 20, pos.Y - 20, 40, 40);
            g.DrawString(state.ToString(), Font, Brushes.Black, pos.X - 10, pos.Y - 10);
        }

        private void CoinButton_Click(object sender, EventArgs e)
        {
        
            var coin = int.Parse((sender as Button).Tag.ToString());
            vm.InsertCoin(coin);
            System.Media.SystemSounds.Exclamation.Play();
            //if (vm.CurrentAmount < 50)
            //    this.BackColor = Color.MistyRose; // light red to warn user
            //else
            //    this.BackColor = SystemColors.Control;

            pnlFA.Invalidate(); // Refresh FA drawing
            
        }


        private void btnPurchase_Click(object sender, EventArgs e)
        {
            var product = lstProducts.SelectedItem as Product;

            if (product != null)
            {
                if (product.Price > 100)
                {
                    MessageBox.Show("Cannot dispense! All products must be ₹100 or less.");
                    System.Media.SystemSounds.Hand.Play();
                }
                else if (vm.PurchaseProduct(product))
                {
                    MessageBox.Show($"Dispensed {product.Name}!");
                    pnlFA.Invalidate();
                    System.Media.SystemSounds.Beep.Play(); // For successful purchase
                    vm.Reset();
                }
                else
                {
                    MessageBox.Show("Insufficient funds! Add more amount");
                    System.Media.SystemSounds.Hand.Play(); // For insufficient funds
                }
                //var product = lstProducts.SelectedItem as Product;
                //if (product != null && vm.PurchaseProduct(product))
                //{
                //    MessageBox.Show($"Dispensed {product.Name}!");
                //    pnlFA.Invalidate();
                //    System.Media.SystemSounds.Beep.Play(); // For successful purchase
                //    vm.Reset();
                //}
                //else
                //{
                //    MessageBox.Show("Insufficient funds! Add more amount");
                //    System.Media.SystemSounds.Hand.Play(); // For insufficient funds
                //}
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            vm.Reset();
            pnlFA.Invalidate();
        }

        //private void button1_Click(object sender, EventArgs e)
        //{

        //}
    }
}
